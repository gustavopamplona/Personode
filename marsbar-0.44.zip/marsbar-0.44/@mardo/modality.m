function mod_str = modality(D)
% method returns modality of design
%
% $Id$ 
  
mod_str = 'unknown';
