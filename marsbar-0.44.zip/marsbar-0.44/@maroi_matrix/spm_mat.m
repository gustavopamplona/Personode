function M = spm_mat(obj)
% spm_mat method - returns mat file defining orientation etc
%
% $Id$

M = obj.mat;