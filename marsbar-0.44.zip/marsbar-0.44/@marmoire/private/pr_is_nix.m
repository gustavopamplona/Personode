function res = pr_is_nix(v)
res = isempty(v) | pr_is_nan(v);
return
