function n = n_time_points(o)
% get number of time_points
% 
% $Id$ 

n = summary_size(o, 1);