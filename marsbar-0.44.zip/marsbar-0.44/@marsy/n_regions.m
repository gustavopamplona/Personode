function n = n_regions(o)
% get number of regions
% 
% $Id$ 

n = summary_size(o, 2);