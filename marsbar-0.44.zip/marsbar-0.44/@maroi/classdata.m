function cdata = classdata(obj, varargin)
% classdata method - sets/gets class data
% See help for private/my_classdata for more details
%
% $Id$

cdata = my_classdata(varargin{:});