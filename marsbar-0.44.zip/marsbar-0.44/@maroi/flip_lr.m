function o = flip_lr(o)
% flips ROI left / right
%
% $Id$  

error('Not defined for this ROI type');