function o = saveobj(o)
% saveobj method - removes temporary voxblock structure
%
% $Id$

o.voxblock = [];